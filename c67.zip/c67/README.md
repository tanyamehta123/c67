# Monkey Chunky App

Monkey Chunky App is designed to help early stage readers practice reading words. The user can enter any word and the app will break it down into phonic chunks. User can tap on the phonic chunks to hear the corresponding sound of the phones that make the word.
